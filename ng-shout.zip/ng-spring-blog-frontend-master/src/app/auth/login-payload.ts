export class LoginPayload{
  username: string;
  password: string
}
