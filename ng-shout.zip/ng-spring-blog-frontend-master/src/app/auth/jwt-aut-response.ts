export class JwtAutResponse {
  authenticationToken: string;
  username: string
}
