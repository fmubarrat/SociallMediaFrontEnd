export class RegisterPayload {
  username: String;
  email: String;
  password: String;
  confirmPassword: String;
}
